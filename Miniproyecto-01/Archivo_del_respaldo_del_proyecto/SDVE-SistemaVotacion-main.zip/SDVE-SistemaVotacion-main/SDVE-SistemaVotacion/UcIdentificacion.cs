﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using SDVE_SistemaVotacion.Services;

namespace SDVE_SistemaVotacion
{
    public class UcIdentificacion : UserControl
    {
        private const int Ancho = 460;

        private readonly Panel contenido = new Panel();
        private readonly Guna2HtmlLabel lblTitulo = new Guna2HtmlLabel();
        private readonly Guna2HtmlLabel lblSub = new Guna2HtmlLabel();
        private readonly Guna2TextBox txtId = new Guna2TextBox();
        private readonly Guna2HtmlLabel lblError = new Guna2HtmlLabel();
        private readonly Guna2Button btnContinuar = new Guna2Button();
   

        public UcIdentificacion()
        {
            BackColor = Color.White;
            contenido.Size = new Size(Ancho, 330);
            contenido.BackColor = Color.Transparent;

            lblTitulo.AutoSize = false;
            lblTitulo.BackColor = Color.Transparent;
            lblTitulo.Text = "Identifícate para votar";
            lblTitulo.TextAlignment = ContentAlignment.MiddleCenter;
            lblTitulo.Size = new Size(Ancho, 46);
            lblTitulo.Location = new Point(0, 0);

            lblSub.AutoSize = false;
            lblSub.BackColor = Color.Transparent;
            lblSub.ForeColor = Color.DimGray;
            lblSub.Text = "Escribe tu Id para comenzar.";
            lblSub.TextAlignment = ContentAlignment.MiddleCenter;
            lblSub.Size = new Size(Ancho, 30);
            lblSub.Location = new Point(0, 52);

            txtId.Size = new Size(Ancho, 54);
            txtId.Location = new Point(0, 100);
            txtId.PlaceholderText = "ID";
            txtId.MaxLength = 30;
            txtId.BorderRadius = 8;
            txtId.TextAlign = HorizontalAlignment.Center;
            txtId.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtId.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtId.TextChanged += (s, e) => lblError.Text = string.Empty;

            lblError.AutoSize = false;
            lblError.BackColor = Color.Transparent;
            lblError.ForeColor = Color.FromArgb(200, 50, 50);
            lblError.Text = string.Empty;
            lblError.TextAlignment = ContentAlignment.MiddleCenter;
            lblError.Size = new Size(Ancho, 30);
            lblError.Location = new Point(0, 162);

            btnContinuar.Size = new Size(Ancho, 58);
            btnContinuar.Location = new Point(0, 200);
            btnContinuar.Text = "Continuar";
            btnContinuar.ForeColor = Color.White;
            btnContinuar.FillColor = Color.FromArgb(230, 81, 0);
            btnContinuar.BorderRadius = 8;
            btnContinuar.Cursor = Cursors.Hand;
            btnContinuar.Click += (s, e) => Continuar();

            
            contenido.Controls.Add(lblTitulo);
            contenido.Controls.Add(lblSub);
            contenido.Controls.Add(txtId);
            contenido.Controls.Add(lblError);
            contenido.Controls.Add(btnContinuar);
            
            Controls.Add(contenido);

            Resize += (s, e) => Centrar();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            lblTitulo.Font = new Font(Font.FontFamily, 22f, FontStyle.Bold);
            lblSub.Font = new Font(Font.FontFamily, 11f);
            lblError.Font = new Font(Font.FontFamily, 10f);
            txtId.Font = new Font(Font.FontFamily, 15f);
            btnContinuar.Font = new Font(Font.FontFamily, 12f, FontStyle.Bold);
            Centrar();
            txtId.Focus();
        }

        /// <summary>Enter dentro del campo de ID equivale a pulsar "Continuar".</summary>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Enter && txtId.ContainsFocus)
            {
                Continuar();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void Centrar()
        {
            contenido.Location = new Point(
                Math.Max(0, (Width - contenido.Width) / 2),
                Math.Max(0, (Height - contenido.Height) / 2));
        }

        private void Volver()
        {
            Form1? ventana = FindForm() as Form1;
            if (ventana != null) ventana.MostrarBienvenida();
        }

        private void Continuar()
        {
            Form1? ventana = FindForm() as Form1;
            if (ventana == null) return;

            string id = txtId.Text.Trim();
            if (id.Length == 0)
            {
                lblError.Text = "Escribe tu ID.";
                return;
            }

            Models.Alumno? alumno;
            try
            {
                alumno = AlmacenPadron.Identificar(id);
            }
            catch (Exception ex) when (ex is IOException || ex is InvalidDataException || ex is UnauthorizedAccessException)
            {
                MessageBox.Show("No se pudo leer el padrón de alumnos: " + ex.Message, "Error en el padrón",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (alumno == null)
            {
                lblError.Text = "Esa matrícula no está en el padrón.";
                return;
            }

            if (AlmacenPadron.Disponibles(alumno).Count == 0)
            {
                lblError.Text = "Ya votaste en todas las convocatorias.";
                return;
            }

 

            ventana.AlumnoActual = alumno;
            ventana.Ir(new UcPapeleta());
        }
    }
}
